const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }
});
const safe = (v, n = 50) => String(v ?? "").trim().slice(0, n);
const now = () => Date.now();

async function readState(env) {
  const result = await env.DB.prepare(
    "SELECT id, device_name AS deviceName, player_name AS playerName, started_at AS startedAt, end_time AS endTime, updated_at AS updatedAt FROM sessions ORDER BY started_at DESC"
  ).all();
  return { sessions: result.results || [], serverNow: now() };
}
async function requirePin(request, env) {
  const configured = env.ADMIN_PIN;
  if (!configured) return false;
  const pin = request.headers.get("x-admin-pin") || "";
  return pin.length > 0 && pin === configured;
}
async function handleApi(request, env, url) {
  if (request.method === "GET" && url.pathname === "/api/state") {
    try { return json(await readState(env)); }
    catch (e) { return json({ error: "قاعدة البيانات غير جاهزة. نفّذ schema.sql أولاً." }, 503); }
  }
  if (request.method === "GET" && url.pathname === "/api/auth") {
    return await requirePin(request, env)
      ? json({ ok: true })
      : json({ error: "رمز التحكم غير صحيح أو لم يتم ضبطه في الاستضافة." }, 401);
  }
  if (!await requirePin(request, env)) return json({ error: "رمز التحكم غير صحيح أو لم يتم ضبطه في الاستضافة." }, 401);

  if (request.method === "POST" && url.pathname === "/api/sessions") {
    let body;
    try { body = await request.json(); } catch { return json({ error: "بيانات غير صالحة." }, 400); }
    const deviceName = safe(body.deviceName);
    const playerName = safe(body.playerName);
    const minutes = Number(body.minutes);
    if (!deviceName || !Number.isFinite(minutes) || minutes < 1 || minutes > 1440)
      return json({ error: "أدخل اسم الجهاز ومدة بين دقيقة و24 ساعة." }, 400);
    const t = now(), id = crypto.randomUUID();
    await env.DB.prepare("INSERT INTO sessions (id, device_name, player_name, started_at, end_time, updated_at) VALUES (?, ?, ?, ?, ?, ?)")
      .bind(id, deviceName, playerName, t, t + Math.round(minutes * 60000), t).run();
    return json({ ok: true, ...(await readState(env)) });
  }
  const match = url.pathname.match(/^\/api\/sessions\/([^/]+)(?:\/(extend))?$/);
  if (match) {
    const id = decodeURIComponent(match[1]);
    if (request.method === "PATCH" && match[2] === "extend") {
      let body;
      try { body = await request.json(); } catch { return json({ error: "بيانات غير صالحة." }, 400); }
      const minutes = Number(body.minutes || 15);
      if (!Number.isFinite(minutes) || minutes < 1 || minutes > 1440) return json({ error: "المدة غير صالحة." }, 400);
      const row = await env.DB.prepare("SELECT end_time AS endTime FROM sessions WHERE id = ?").bind(id).first();
      if (!row) return json({ error: "الجلسة غير موجودة." }, 404);
      const t = now();
      await env.DB.prepare("UPDATE sessions SET end_time = ?, updated_at = ? WHERE id = ?")
        .bind(Math.max(Number(row.endTime), t) + Math.round(minutes * 60000), t, id).run();
      return json({ ok: true, ...(await readState(env)) });
    }
    if (request.method === "DELETE" && !match[2]) {
      await env.DB.prepare("DELETE FROM sessions WHERE id = ?").bind(id).run();
      return json({ ok: true, ...(await readState(env)) });
    }
  }
  return json({ error: "المسار غير موجود." }, 404);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === "/tv") return Response.redirect(new URL("/index.html", url), 302);
    if (url.pathname === "/control") return Response.redirect(new URL("/control.html", url), 302);
    if (url.pathname.startsWith("/api/")) {
      try { return await handleApi(request, env, url); }
      catch (e) { return json({ error: "حدث خطأ بالخادم. تأكد من إعداد D1 وتشغيل schema.sql." }, 500); }
    }
    return env.ASSETS.fetch(request);
  }
};