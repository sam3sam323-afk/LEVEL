CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  device_name TEXT NOT NULL,
  player_name TEXT NOT NULL DEFAULT '',
  started_at INTEGER NOT NULL,
  end_time INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS sessions_end_time_idx ON sessions(end_time);